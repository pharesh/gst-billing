<?php $__env->startSection('content'); ?>
<div class="header">
  <h1>Payment Reminder</h1>
  <p>Invoice #<?php echo e($invoice->invoice_number); ?> — <?php echo e($invoice->tenant->name); ?></p>
</div>
<div class="body">
  <p>Dear <strong><?php echo e($invoice->customer->name); ?></strong>,</p>
  <p>This is a friendly reminder that the following invoice is pending payment:</p>

  <div class="highlight-box">
    <div class="label">Amount Due</div>
    <div class="value">₹<?php echo e(number_format($invoice->balance_due, 2)); ?></div>
  </div>

  <table class="info-table">
    <tr><td>Invoice No.</td><td><?php echo e($invoice->invoice_number); ?></td></tr>
    <tr><td>Invoice Date</td><td><?php echo e($invoice->invoice_date->format('d M Y')); ?></td></tr>
    <?php if($invoice->due_date): ?>
    <tr>
      <td>Due Date</td>
      <td style="color:<?php echo e($invoice->isOverdue() ? '#dc2626' : '#333'); ?>; font-weight:600;">
        <?php echo e($invoice->due_date->format('d M Y')); ?>

        <?php if($invoice->isOverdue()): ?> (OVERDUE) <?php endif; ?>
      </td>
    </tr>
    <?php endif; ?>
    <tr><td>Total Invoice</td><td>₹<?php echo e(number_format($invoice->total_amount, 2)); ?></td></tr>
    <?php if($invoice->amount_paid > 0): ?>
    <tr><td>Paid So Far</td><td class="status-paid">₹<?php echo e(number_format($invoice->amount_paid, 2)); ?></td></tr>
    <?php endif; ?>
    <tr><td>Balance Due</td><td><strong>₹<?php echo e(number_format($invoice->balance_due, 2)); ?></strong></td></tr>
  </table>

  <?php if($invoice->tenant->bank_details): ?>
  <?php $bank = $invoice->tenant->bank_details; ?>
  <p style="margin-top:20px;"><strong>Please transfer to:</strong></p>
  <table class="info-table">
    <?php if($bank['bank_name'] ?? false): ?><tr><td>Bank</td><td><?php echo e($bank['bank_name']); ?></td></tr><?php endif; ?>
    <?php if($bank['account_no'] ?? false): ?><tr><td>Account No.</td><td><?php echo e($bank['account_no']); ?></td></tr><?php endif; ?>
    <?php if($bank['ifsc'] ?? false): ?><tr><td>IFSC Code</td><td><?php echo e($bank['ifsc']); ?></td></tr><?php endif; ?>
  </table>
  <?php endif; ?>

  <p style="margin-top:20px;">Please make the payment at the earliest. If you have already paid, please ignore this reminder.</p>
  <p>Regards,<br><strong><?php echo e($invoice->tenant->name); ?></strong><br>
  <?php if($invoice->tenant->phone): ?><small><?php echo e($invoice->tenant->phone); ?></small><?php endif; ?></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HARESH\Herd\gst-billing\resources\views/mail/payment-reminder.blade.php ENDPATH**/ ?>