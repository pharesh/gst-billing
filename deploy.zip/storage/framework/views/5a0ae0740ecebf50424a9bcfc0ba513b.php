<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Invoice - <?php echo e($invoice->invoice_number); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 11px; color: #222; }
        .page { padding: 20px; }
        .header { display: table; width: 100%; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 10px; }
        .header-left { display: table-cell; width: 60%; vertical-align: top; }
        .header-right { display: table-cell; width: 40%; text-align: right; vertical-align: top; }
        .company-name { font-size: 18px; font-weight: bold; color: #1a1a2e; }
        .company-gstin { font-size: 10px; color: #555; margin-top: 2px; }
        .invoice-title { font-size: 16px; font-weight: bold; color: #1a1a2e; }
        .invoice-meta { font-size: 10px; margin-top: 4px; color: #444; }
        .parties { display: table; width: 100%; margin-bottom: 12px; }
        .party-box { display: table-cell; width: 50%; vertical-align: top; padding: 8px; border: 1px solid #ddd; }
        .party-box:first-child { border-right: none; }
        .party-label { font-size: 9px; font-weight: bold; color: #888; text-transform: uppercase; margin-bottom: 4px; }
        .party-name { font-size: 12px; font-weight: bold; }
        .party-detail { font-size: 10px; color: #444; margin-top: 2px; }
        table.items { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        table.items th { background: #1a1a2e; color: #fff; padding: 6px 8px; font-size: 10px; text-align: left; }
        table.items td { padding: 5px 8px; border-bottom: 1px solid #eee; font-size: 10px; }
        table.items tr:nth-child(even) td { background: #f9f9f9; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .totals-table { width: 280px; float: right; border-collapse: collapse; margin-bottom: 10px; }
        .totals-table td { padding: 4px 8px; font-size: 10px; }
        .totals-table .label { color: #555; }
        .totals-table .grand-total { font-weight: bold; font-size: 12px; background: #1a1a2e; color: #fff; }
        .amount-words { clear: both; background: #f5f5f5; padding: 8px; border-radius: 3px; font-size: 10px; margin-bottom: 10px; }
        .tax-summary { margin-bottom: 10px; }
        .tax-summary table { width: 100%; border-collapse: collapse; }
        .tax-summary table th { background: #f0f0f0; padding: 5px 8px; font-size: 9px; border: 1px solid #ddd; }
        .tax-summary table td { padding: 4px 8px; font-size: 10px; border: 1px solid #ddd; }
        .footer { border-top: 1px solid #ddd; margin-top: 10px; padding-top: 10px; display: table; width: 100%; }
        .footer-left { display: table-cell; width: 60%; font-size: 9px; color: #666; }
        .footer-right { display: table-cell; width: 40%; text-align: right; font-size: 10px; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 9px; font-weight: bold; }
        .badge-paid { background: #d4edda; color: #155724; }
        .badge-unpaid { background: #f8d7da; color: #721c24; }
        .badge-partial { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
<div class="page">

    
    <div class="header">
        <div class="header-left">
            <?php if($invoice->tenant->logo): ?>
                <img src="<?php echo e(public_path('storage/' . $invoice->tenant->logo)); ?>" height="50" style="margin-bottom:6px;"><br>
            <?php endif; ?>
            <div class="company-name"><?php echo e($invoice->tenant->name); ?></div>
            <?php if($invoice->tenant->address): ?>
                <div class="company-gstin"><?php echo e($invoice->tenant->address); ?>, <?php echo e($invoice->tenant->city); ?>, <?php echo e($invoice->tenant->state); ?> - <?php echo e($invoice->tenant->pincode); ?></div>
            <?php endif; ?>
            <?php if($invoice->tenant->gstin): ?>
                <div class="company-gstin">GSTIN: <?php echo e($invoice->tenant->gstin); ?></div>
            <?php endif; ?>
            <?php if($invoice->tenant->phone): ?>
                <div class="company-gstin">Phone: <?php echo e($invoice->tenant->phone); ?> | Email: <?php echo e($invoice->tenant->email); ?></div>
            <?php endif; ?>
        </div>
        <div class="header-right">
            <div class="invoice-title">TAX INVOICE</div>
            <div class="invoice-meta">
                <strong>Invoice #:</strong> <?php echo e($invoice->invoice_number); ?><br>
                <strong>Date:</strong> <?php echo e($invoice->invoice_date->format('d M Y')); ?><br>
                <?php if($invoice->due_date): ?>
                    <strong>Due Date:</strong> <?php echo e($invoice->due_date->format('d M Y')); ?><br>
                <?php endif; ?>
                <strong>Status:</strong>
                <span class="badge badge-<?php echo e($invoice->payment_status); ?>"><?php echo e(strtoupper($invoice->payment_status)); ?></span>
            </div>
        </div>
    </div>

    
    <div class="parties">
        <div class="party-box">
            <div class="party-label">Bill To</div>
            <div class="party-name"><?php echo e($invoice->customer->name); ?></div>
            <?php if($invoice->customer->gstin): ?>
                <div class="party-detail">GSTIN: <?php echo e($invoice->customer->gstin); ?></div>
            <?php endif; ?>
            <?php if($invoice->customer->address): ?>
                <div class="party-detail"><?php echo e($invoice->customer->address); ?>, <?php echo e($invoice->customer->city); ?></div>
                <div class="party-detail"><?php echo e($invoice->customer->state); ?> - <?php echo e($invoice->customer->pincode); ?></div>
            <?php endif; ?>
            <?php if($invoice->customer->phone): ?>
                <div class="party-detail">Phone: <?php echo e($invoice->customer->phone); ?></div>
            <?php endif; ?>
        </div>
        <div class="party-box">
            <div class="party-label">Supply Details</div>
            <div class="party-detail"><strong>Supply Type:</strong> <?php echo e(ucfirst($invoice->supply_type)); ?></div>
            <div class="party-detail"><strong>Invoice Type:</strong> <?php echo e(strtoupper($invoice->invoice_type)); ?></div>
            <?php if($invoice->tenant->bank_details): ?>
                <div class="party-label" style="margin-top:8px;">Bank Details</div>
                <?php $bank = $invoice->tenant->bank_details; ?>
                <div class="party-detail"><?php echo e($bank['bank_name'] ?? ''); ?></div>
                <div class="party-detail">A/C: <?php echo e($bank['account_no'] ?? ''); ?></div>
                <div class="party-detail">IFSC: <?php echo e($bank['ifsc'] ?? ''); ?></div>
            <?php endif; ?>
        </div>
    </div>

    
    <table class="items">
        <thead>
            <tr>
                <th>#</th>
                <th>Description</th>
                <th>HSN/SAC</th>
                <th>Qty</th>
                <th>Unit</th>
                <th class="text-right">Rate (₹)</th>
                <th class="text-right">Taxable Value (₹)</th>
                <?php if($invoice->supply_type === 'intrastate'): ?>
                    <th class="text-right">CGST</th>
                    <th class="text-right">SGST</th>
                <?php else: ?>
                    <th class="text-right">IGST</th>
                <?php endif; ?>
                <th class="text-right">Total (₹)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->hsn_sac_code ?? '-'); ?></td>
                <td class="text-center"><?php echo e($item->quantity); ?></td>
                <td class="text-center"><?php echo e($item->unit); ?></td>
                <td class="text-right"><?php echo e(number_format($item->price, 2)); ?></td>
                <td class="text-right"><?php echo e(number_format($item->taxable_amount, 2)); ?></td>
                <?php if($invoice->supply_type === 'intrastate'): ?>
                    <td class="text-right"><?php echo e($item->cgst_rate); ?>%<br><?php echo e(number_format($item->cgst_amount, 2)); ?></td>
                    <td class="text-right"><?php echo e($item->sgst_rate); ?>%<br><?php echo e(number_format($item->sgst_amount, 2)); ?></td>
                <?php else: ?>
                    <td class="text-right"><?php echo e($item->igst_rate); ?>%<br><?php echo e(number_format($item->igst_amount, 2)); ?></td>
                <?php endif; ?>
                <td class="text-right"><strong><?php echo e(number_format($item->total_amount, 2)); ?></strong></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    
    <table class="totals-table">
        <tr>
            <td class="label">Subtotal (Taxable Value)</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->subtotal, 2)); ?></td>
        </tr>
        <?php if($invoice->cgst_amount > 0): ?>
        <tr>
            <td class="label">CGST</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->cgst_amount, 2)); ?></td>
        </tr>
        <tr>
            <td class="label">SGST</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->sgst_amount, 2)); ?></td>
        </tr>
        <?php endif; ?>
        <?php if($invoice->igst_amount > 0): ?>
        <tr>
            <td class="label">IGST</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->igst_amount, 2)); ?></td>
        </tr>
        <?php endif; ?>
        <?php if($invoice->discount_amount > 0): ?>
        <tr>
            <td class="label">Discount</td>
            <td class="text-right">- ₹ <?php echo e(number_format($invoice->discount_amount, 2)); ?></td>
        </tr>
        <?php endif; ?>
        <tr class="grand-total">
            <td>Total Amount</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->total_amount, 2)); ?></td>
        </tr>
        <?php if($invoice->amount_paid > 0): ?>
        <tr>
            <td class="label">Amount Paid</td>
            <td class="text-right">₹ <?php echo e(number_format($invoice->amount_paid, 2)); ?></td>
        </tr>
        <tr>
            <td class="label"><strong>Balance Due</strong></td>
            <td class="text-right"><strong>₹ <?php echo e(number_format($invoice->balance_due, 2)); ?></strong></td>
        </tr>
        <?php endif; ?>
    </table>

    
    <div class="amount-words" style="clear:both;">
        <strong>Amount in Words:</strong> <?php echo e($amountInWords); ?>

    </div>

    
    <?php if(count($gstGroups) > 0): ?>
    <div class="tax-summary">
        <table>
            <thead>
                <tr>
                    <th>GST Rate</th>
                    <th class="text-right">Taxable Amount (₹)</th>
                    <?php if($invoice->supply_type === 'intrastate'): ?>
                        <th class="text-right">CGST (₹)</th>
                        <th class="text-right">SGST (₹)</th>
                    <?php else: ?>
                        <th class="text-right">IGST (₹)</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $gstGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($group['gst_rate']); ?>%</td>
                    <td class="text-right"><?php echo e(number_format($group['taxable_amount'], 2)); ?></td>
                    <?php if($invoice->supply_type === 'intrastate'): ?>
                        <td class="text-right"><?php echo e(number_format($group['cgst_amount'], 2)); ?></td>
                        <td class="text-right"><?php echo e(number_format($group['sgst_amount'], 2)); ?></td>
                    <?php else: ?>
                        <td class="text-right"><?php echo e(number_format($group['igst_amount'], 2)); ?></td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    
    <div class="footer">
        <div class="footer-left">
            <?php if($invoice->notes): ?>
                <strong>Notes:</strong> <?php echo e($invoice->notes); ?><br>
            <?php endif; ?>
            <?php if($invoice->terms): ?>
                <strong>Terms & Conditions:</strong> <?php echo e($invoice->terms); ?><br>
            <?php endif; ?>
            <br>This is a computer-generated invoice.
        </div>
        <div class="footer-right">
            <br><br>
            <?php if($invoice->tenant->signature): ?>
                <img src="<?php echo e(public_path('storage/' . $invoice->tenant->signature)); ?>" height="40"><br>
            <?php endif; ?>
            <strong><?php echo e($invoice->tenant->name); ?></strong><br>
            Authorised Signatory
        </div>
    </div>

</div>
</body>
</html>
<?php /**PATH C:\Users\HARESH\Herd\gst-billing\resources\views/invoices/pdf.blade.php ENDPATH**/ ?>