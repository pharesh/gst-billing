<?php $__env->startSection('content'); ?>
<div class="header">
  <h1>Payment Received ✓</h1>
  <p>Invoice #<?php echo e($invoice->invoice_number); ?> — <?php echo e($invoice->tenant->name); ?></p>
</div>
<div class="body">
  <p>Dear <strong><?php echo e($invoice->customer->name); ?></strong>,</p>
  <p>We have received your payment. Thank you!</p>

  <div class="highlight-box">
    <div class="label">Amount Received</div>
    <div class="value" style="color:#16a34a;">₹<?php echo e(number_format($payment->amount, 2)); ?></div>
  </div>

  <table class="info-table">
    <tr><td>Invoice No.</td><td><?php echo e($invoice->invoice_number); ?></td></tr>
    <tr><td>Payment Date</td><td><?php echo e($payment->payment_date->format('d M Y')); ?></td></tr>
    <tr><td>Payment Method</td><td><?php echo e(ucwords(str_replace('_', ' ', $payment->payment_method))); ?></td></tr>
    <?php if($payment->reference_number): ?>
    <tr><td>Reference / UTR</td><td><?php echo e($payment->reference_number); ?></td></tr>
    <?php endif; ?>
    <tr><td>Invoice Total</td><td>₹<?php echo e(number_format($invoice->total_amount, 2)); ?></td></tr>
    <tr><td>Total Paid</td><td class="status-paid">₹<?php echo e(number_format($invoice->amount_paid, 2)); ?></td></tr>
    <?php if($invoice->balance_due > 0): ?>
    <tr><td>Balance Due</td><td class="status-unpaid">₹<?php echo e(number_format($invoice->balance_due, 2)); ?></td></tr>
    <?php else: ?>
    <tr><td>Status</td><td class="status-paid">FULLY PAID</td></tr>
    <?php endif; ?>
  </table>

  <p style="margin-top:20px;">Thank you for your prompt payment. We look forward to serving you again.</p>
  <p>Regards,<br><strong><?php echo e($invoice->tenant->name); ?></strong></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HARESH\Herd\gst-billing\resources\views/mail/payment-confirmed.blade.php ENDPATH**/ ?>