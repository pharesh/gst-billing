<?php $__env->startSection('content'); ?>
<div class="header">
  <h1>Invoice from <?php echo e($invoice->tenant->name); ?></h1>
  <p>Invoice #<?php echo e($invoice->invoice_number); ?> • <?php echo e($invoice->invoice_date->format('d M Y')); ?></p>
</div>
<div class="body">
  <p>Dear <strong><?php echo e($invoice->customer->name); ?></strong>,</p>
  <p>Please find your invoice attached to this email. Here is a summary:</p>

  <div class="highlight-box">
    <div class="label">Amount Due</div>
    <div class="value">₹<?php echo e(number_format($invoice->balance_due, 2)); ?></div>
  </div>

  <table class="info-table">
    <tr><td>Invoice No.</td><td><?php echo e($invoice->invoice_number); ?></td></tr>
    <tr><td>Invoice Date</td><td><?php echo e($invoice->invoice_date->format('d M Y')); ?></td></tr>
    <?php if($invoice->due_date): ?>
    <tr><td>Due Date</td><td><?php echo e($invoice->due_date->format('d M Y')); ?></td></tr>
    <?php endif; ?>
    <tr><td>Subtotal</td><td>₹<?php echo e(number_format($invoice->subtotal, 2)); ?></td></tr>
    <tr><td>GST</td><td>₹<?php echo e(number_format($invoice->cgst_amount + $invoice->sgst_amount + $invoice->igst_amount, 2)); ?></td></tr>
    <tr><td>Total Amount</td><td><strong>₹<?php echo e(number_format($invoice->total_amount, 2)); ?></strong></td></tr>
    <tr><td>Payment Status</td><td class="status-<?php echo e($invoice->payment_status); ?>"><?php echo e(strtoupper($invoice->payment_status)); ?></td></tr>
  </table>

  <?php if($invoice->tenant->bank_details): ?>
  <?php $bank = $invoice->tenant->bank_details; ?>
  <p style="margin-top:20px;"><strong>Payment Details:</strong></p>
  <table class="info-table">
    <?php if($bank['bank_name'] ?? false): ?><tr><td>Bank</td><td><?php echo e($bank['bank_name']); ?></td></tr><?php endif; ?>
    <?php if($bank['account_no'] ?? false): ?><tr><td>Account No.</td><td><?php echo e($bank['account_no']); ?></td></tr><?php endif; ?>
    <?php if($bank['ifsc'] ?? false): ?><tr><td>IFSC Code</td><td><?php echo e($bank['ifsc']); ?></td></tr><?php endif; ?>
  </table>
  <?php endif; ?>

  <?php if($invoice->notes): ?>
  <p style="color:#666;font-size:13px;margin-top:16px;"><em>Note: <?php echo e($invoice->notes); ?></em></p>
  <?php endif; ?>

  <p style="margin-top:20px;">Thank you for your business!</p>
  <p>Regards,<br><strong><?php echo e($invoice->tenant->name); ?></strong></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HARESH\Herd\gst-billing\resources\views/mail/invoice.blade.php ENDPATH**/ ?>